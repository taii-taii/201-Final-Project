

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class codeformservlet
 */
@WebServlet("/codeformservlet")
public class codeformservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public codeformservlet() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String name = "";
	    String textfield = "";

			name = request.getParameter("title");
			textfield = request.getParameter("codetext");
			if(name.isEmpty()) {

			} else if(textfield.isEmpty()) {

			}
	    //create new file/see if old one exists, write current text to file
	   /*
		try {
	      File myObj = new File(name);
	      if (myObj.createNewFile()) {
	        System.out.println("File created: " + myObj.getName());
	      } else {
	        System.out.println("File already exists.");
	      }
	    } catch (IOException e) {
	      e.printStackTrace();
	    }

	    try {
	      FileWriter myWriter = new FileWriter(name);
	      myWriter.write(textfield);
	      myWriter.close();
	      System.out.println("Successfully wrote to the file.");
	    } catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	*/

//			FileOutputStream out1 = new FileOutputStream(name);
//			 
//			out1.write(textfield.getBytes());
//			out1.close();
			String path = getServletContext().getRealPath("/WEB-INF/");
			File file = new File(path + "\\" + name);
			if(!file.exists()) {
		        System.out.println("creating file");
		        if(file.createNewFile()) {
		        System.out.println("Succesfully created file");
		        } else{
		        System.out.println("Failed to create file");
		        }
		    }
			try {
			      FileWriter myWriter = new FileWriter(path + "\\" + name);
			      myWriter.write(textfield);
			      myWriter.close();
			      System.out.println("Successfully wrote to the file.");
			    } catch (IOException e) {
			      System.out.println("An error occurred.");
			      e.printStackTrace();
			    }

			System.out.println(name + textfield);
//			PrintWriter out = response.getWriter();
//			response.setContentType("text/html");
//			out.println("<html>");
//			out.println("<body>");
//			out.println("<head>");
//			out.println("<title> Form Submission </title>");
//			out.println("<h1> Form Submission </h1>");
//			out.println("</body>");
//			out.println("</head>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	
	}

}
