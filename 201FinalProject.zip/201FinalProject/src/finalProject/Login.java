package finalProject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class Login {
	public Connection conn;
	Statement st;
	PreparedStatement ps;
	ResultSet rs;
	
	public Login(){
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj?serverTimezone=UTC", "root", "MAkdessi22"); 
			st = conn.createStatement();			
		} catch(SQLException sqle){
			System.out.println ("SQLException: " + sqle.getMessage());
		} catch(ClassNotFoundException cnfe) {
			System.out.println("Class not found exception: " + cnfe.getMessage());
		}
		
	}
	
	public static String hash(String password, int salt) {
		if (password == null || password.length() == 0) {
            throw new IllegalArgumentException("Empty passwords are not supported.");
		}
		MessageDigest md = null;
		try {
			md = MessageDigest.getInstance("SHA-256");
		} catch (NoSuchAlgorithmException e) {
			System.out.println("NoSuchAlgorithmException: " + e.getMessage());
		}
		md.update((byte) salt);
		byte[] hashed = md.digest(password.getBytes(StandardCharsets.UTF_8));
		StringBuffer hexString = new StringBuffer();

        for (int i = 0; i < hashed.length; i++) {
            String hex = Integer.toHexString(0xff & hashed[i]);
            if(hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
	}
	
	public static String encryptPassword(String password) throws IllegalArgumentException {
		SecureRandom random = new SecureRandom();
		
		int salt = random.nextInt();
        return salt + "$" + hash(password, salt);
    }
	
	public void ResetPassword(String username, String newPassword) throws SQLException {
		if(!VerifyUser(username)){
			System.out.println("User doesn't exist.");
			return;
		} else {
			newPassword = encryptPassword(newPassword);
			st.executeUpdate("UPDATE UserInfo SET password='" + newPassword + "' WHERE username='" + username + "'");
		}
	}
	
	public void CreateUser(String email, String password) throws SQLException {
	
		if(VerifyUser(email)){
			System.out.println("User already exists.");
			return;
		}

		System.out.println("unencrypted password is: " + password);
		
		password = encryptPassword(password);
		
		System.out.println("encrypted password is: " + password);
		
		st.executeUpdate("INSERT INTO Users VALUES ('" + email +"','" + password + "')");
	}
	
	public boolean CheckPassword(String email,String password) throws SQLException {
		
		if(VerifyUser(email)){
			ps = conn.prepareStatement("SELECT * FROM Users WHERE email='" + email + "';");
			rs = ps.executeQuery();
			rs.next();
			String[] saltAndHash = rs.getString("password").split("\\$");
			String hashed = hash(password, Integer.parseInt(saltAndHash[0]));
			return hashed.equals(saltAndHash[1]);
		}
		return false;
	}
	
	public boolean VerifyUser(String email) throws SQLException {				
		ps = conn.prepareStatement("SELECT EXISTS(SELECT * FROM Users WHERE email='" + email +"')");
		rs = ps.executeQuery();

		rs.next();
		if(rs.getBoolean(1)){
			return true;
		}
		return false;
	}
	
	public String getProject(String docID) {
		
		System.out.println("Guest trying to find document with id " + docID);
		
		try {
			ps = conn.prepareStatement("SELECT DocumentName FROM Documents docs WHERE docs.documentID='"+ docID + "'");
			rs = ps.executeQuery();
			rs.next();
			
			String name = rs.getString("documentName");
			System.out.println("Found " + name);
			return name;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null; 
	}	
}
