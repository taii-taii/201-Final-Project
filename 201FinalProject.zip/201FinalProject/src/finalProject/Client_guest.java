package finalProject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.LinkedList;
import java.util.Scanner;

import finalProject.diff_match_patch.Patch;

public class Client_guest {
    private static String clientText = "";
	private static String clientShadow;
	private static Scanner scan;
	private static diff_match_patch dmp;
	private static transient LinkedList<diff_match_patch.Patch> list_of_patches_incoming;
	private static transient LinkedList<diff_match_patch.Patch> list_of_patches_outgoing;
	private static LinkedList<diff_match_patch.Patch> list_of_patches_server;
    Object[] textString;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;
    
    private String docID; 
    
	public Client_guest(String docID) {
		
this.docID = docID; 
		
		dmp = new diff_match_patch();
		scan = new Scanner(System.in);
		Socket s;
		String serverTextTemp;
		
		// Connect to the port
		try {
			s = new Socket("localhost", 3456);
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			
			oos.writeObject(docID); 
			serverTextTemp = "";
			serverTextTemp = (String) ois.readObject(); //blocking 

			clientText = serverTextTemp;
			clientShadow =serverTextTemp;
			
		} catch (IOException e) {
			System.out.println("Error in connecting port/host. Exiting program...");
			System.exit(0);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
		
		
		try {
			// reading info from server threads ois stream
			while(true) {

				// Get the server patches
				String[] serverUpdates = (String[]) ois.readObject();
				list_of_patches_server = dmp.patch_make(serverUpdates[1], serverUpdates[0]);
				
				// Update the client text and client shadow
				clientShadow = serverUpdates[0];
				textString = dmp.patch_apply(list_of_patches_server, clientText);
				clientText = (String) textString[0];
				
				System.out.println("The updated client text is: ");
				System.out.println(clientText);

			}
		} catch (IOException ioe) {
			System.out.println("ioe in Client run: " + ioe.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println("class not found in Client run: " + e.getMessage());
		}
	

	}
	
	public static void main(String args[]) {
		//Client client = new Client("abc123");
	}

}
