package finalProject;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class GuestServlet
 */
@WebServlet("/GuestServlet")
public class GuestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Login l = new Login(); 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GuestServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = "guest"; 
		String docID = (String) request.getParameter("docID"); 
		HttpSession session = request.getSession(); 
		
		String documentName = l.getProject(docID); // sus line
		
		System.out.println("continuing as guest in servlet with docID " + docID);
		
		
		if (documentName == null) {
			System.out.println("No document was found with id " + docID);
			request.setAttribute("error", "invalid document id"); 
			
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/ContinueAsGuest.html");
			dispatch.forward(request,response);
		}
		else {
			System.out.println("Document was found with id " + docID);
			
			session.setAttribute("email", email);
			
			request.setAttribute("email", email);
			request.setAttribute("documentID", docID);
			request.setAttribute("documentName", documentName);
			
			session.setAttribute("email", email);
			session.setAttribute("documentID", docID);
			session.setAttribute("documentName", documentName);
			
			
			RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/textEditor.jsp");
			dispatch.forward(request,response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	

}
