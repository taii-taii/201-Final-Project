package finalProject;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class codeformservlet
 */
@WebServlet("/codeformservlet")



public class codeformservlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public codeformservlet() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String name = "";
	    String textfield = "";

			name = request.getParameter("title");
			textfield = request.getParameter("codetext");
			if(name.isEmpty()) {

			} else if(textfield.isEmpty()) {

			}
			System.out.println(name + textfield);
			String outs = exec(textfield);
			//outs.replaceAll("output:", ""); extract output tect from output response
			request.setAttribute("outputText", outs);
//			PrintWriter out = response.getWriter();
//			out.println("<html><body>"
//					+ "<h4>Output</h4>"
//					+ "<p>" + outs + "</p>"
//					+"</body></html>");
			//response.sendRedirect(request.getHeader("referer"));
			request.getRequestDispatcher("OutputForm.jsp").forward(request, response);
			
			
			
			
			//create new file/see if old one exists, write current text to file

//			FileOutputStream out1 = new FileOutputStream(name);
//			 
//			out1.write(textfield.getBytes());
//			out1.close();
//			String path = getServletContext().getRealPath("/WEB-INF/");
//			File file = new File(path + "\\" + name);
//			if(!file.exists()) {
//		        System.out.println("creating file");
//		        if(file.createNewFile()) {
//		        System.out.println("Succesfully created file");
//		        } else{
//		        System.out.println("Failed to create file");
//		        }
//		    }
//			try {
//			      FileWriter myWriter = new FileWriter(path + "\\" + name);
//			      myWriter.write(textfield);
//			      myWriter.close();
//			      System.out.println("Successfully wrote to the file.");
//			    } catch (IOException e) {
//			      System.out.println("An error occurred.");
//			      e.printStackTrace();
//			    }

			

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	
	}
	
	public String exec(String inp) {
		String clientId = "9908d60f8e1cca502b94af856ba5906d"; //Replace with your client ID
	    String clientSecret = "908e29089c5754f1760a6295873ed52bf90ce445fd441f918f1a1a4feebe5ff7"; //Replace with your client Secret
	   /*
	    String script = "public class MyClass { "
	    		+ "public static void main(String args[]) {"
	    		+ "System.out.println(\"Sum of + 5\");"
	    		+ "} }";
	    	*/
	    String script = inp;
	    //String language = "java";
	    String language = "python3";
	    String versionIndex = "3";
	    String full_out = "";

	    try {
	        URL url = new URL("https://api.jdoodle.com/v1/execute");
	        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
	        connection.setDoOutput(true);
	        connection.setRequestMethod("POST");
	        connection.setRequestProperty("Content-Type", "application/json");

	        String input = "{\"clientId\": \"" + clientId + "\",\"clientSecret\":\"" + clientSecret + "\",\"script\":\"" + script +
	        "\",\"language\":\"" + language + "\",\"versionIndex\":\"" + versionIndex + "\"} ";

	        System.out.println(input);

	        OutputStream outputStream = connection.getOutputStream();
	        outputStream.write(input.getBytes());
	        outputStream.flush();

	        if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
	            throw new RuntimeException("Please check your inputs : HTTP error code : "+ connection.getResponseCode());
	        }

	        BufferedReader bufferedReader;
	        bufferedReader = new BufferedReader(new InputStreamReader((connection.getInputStream())));

	        String output;
	        System.out.println("Output from JDoodle .... \n");
	        while ((output = bufferedReader.readLine()) != null) {
	        	full_out+=output;
	            System.out.println(output);
	        }
	        
	        connection.disconnect();
	    } catch (MalformedURLException e) {
	        e.printStackTrace();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
		return full_out;
	}

}
