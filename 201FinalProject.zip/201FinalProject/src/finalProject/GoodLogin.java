package finalProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class GoodLogin {
	public Connection conn;
	Statement st;
	PreparedStatement ps;
	ResultSet rs;
	
	public GoodLogin(){
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj?serverTimezone=UTC", "root", "MAkdessi22"); 
			st = conn.createStatement();			
		} catch(SQLException sqle){
			System.out.println ("SQLException: " + sqle.getMessage());
		} catch(ClassNotFoundException cnfe) {
			System.out.println("Class not found exception: " + cnfe.getMessage());
		}
		
	}
	
	public void ResetPassword(String username, String newPassword) throws SQLException{
		if(!VerifyUser(username)){
			System.out.println("User doesn't exist.");
			return;
		} else {
			st.executeUpdate("UPDATE UserInfo SET password='" + newPassword + "' WHERE username='" + username + "'");
		}
	}
	
	public void CreateUser(String email, String password) throws SQLException{
	
		if(VerifyUser(email)){
			System.out.println("User already exists.");
			return;
		}
		st.executeUpdate("INSERT INTO Users VALUES ('" + email +"','" +password + "')");
	}
	
	public boolean CheckPassword(String email,String password) throws SQLException{
		
		if(VerifyUser(email)){
			ps = conn.prepareStatement("SELECT * FROM Users WHERE email='" + email + "';");
			rs = ps.executeQuery();
			rs.next();
			if(rs.getString("password").equals(password)){
				return true;
			}
		}
		return false;
	}
	
	public boolean VerifyUser(String email) throws SQLException{				
		ps = conn.prepareStatement("SELECT EXISTS(SELECT * FROM Users WHERE email='" + email +"')");
		rs = ps.executeQuery();

		rs.next();
		if(rs.getBoolean(1)){
			return true;
		}
		return false;
	}
	
	public String getProject(String docID) {
		
		System.out.println("Guest trying to find document with id " + docID);
		
		try {
			ps = conn.prepareStatement("SELECT DocumentName FROM Documents docs WHERE docs.documentID='"+ docID + "'");
//			"SELECT * FROM Documents WHERE documentID='"+ docID + "'");
			rs = ps.executeQuery();
			rs.next();
			
			String name = rs.getString("documentName");
			System.out.println("Found " + name);
			return name;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null; 
	}

	
}
