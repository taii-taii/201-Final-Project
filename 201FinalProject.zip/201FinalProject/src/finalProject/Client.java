package finalProject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.LinkedList;
//import java.util.Scanner;

import finalProject.diff_match_patch.Patch;

public class Client extends Thread { 
	
    private static String clientText = "";
	private static String clientShadow = "";
	//private static Scanner scan;
	private static diff_match_patch dmp;
	private static LinkedList<diff_match_patch.Patch> list_of_patches_server;
    private ObjectInputStream ois;
    private ObjectOutputStream oos;
    Object[] textString;
    private String docID = "def456"; 
    private String username; 
    private String password = "sql"; 

	public Client(String docID, String email) {
		
		this.username = email; 
		
		this.docID = docID; 
		
		dmp = new diff_match_patch();
		//scan = new Scanner(System.in);
		Socket s;
		String serverTextTemp;
		
		// Connect to the port
		try {
			s = new Socket("localhost", 6789);
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			
	
			oos.writeObject(docID); 
			serverTextTemp = "";
			serverTextTemp = (String) ois.readObject(); //blocking 
			

			clientText = serverTextTemp;
			clientShadow =serverTextTemp;
			
		} catch (IOException e) {
			System.out.println("Error in connecting port/host. Exiting program...");
			System.exit(0);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		// Get the original server text and update the client text and client shadow
		// pull from database in actual implementation
		
		// Used to check for upates from other clients

		this.start();
	}
	

	public static void main(String args[]) {
		//Client client = new Client("abc123");
	}
	
	
	public String getText() {
		
		System.out.println(username + " recieved a get from the html and sent: " + clientText);
		return clientText; 
		
	}
	
	public void setText(String text) {
		
		
		clientText = text; 
		try {
			// Send an array of the client shadow and the new text to the server
			String[] clientUpdates = {clientShadow, clientText};
			oos.writeObject(clientUpdates);

			clientShadow = clientText;
			
			System.out.println("The updated client text for " + username + " is: ");
			System.out.println(clientText);

		} catch (IOException e) {
			System.out.println("ioe in Client: " + e.getMessage());
		}
	}

	// If a different client updates the server text, update this client's text to reflect the change
	public void run() {
		try {
			// reading info from server threads ois stream
			while(true) {

				// Get the server patches
				String[] serverUpdates = (String[]) ois.readObject(); //blocking and never pass
				
				System.out.println("we got to this line for " + username );
				System.out.println("and we have at pos 0 " + serverUpdates[0]);
				System.out.println("and we have at pos 1 " + serverUpdates[1]);
				
				list_of_patches_server = dmp.patch_make(serverUpdates[1], serverUpdates[0]);
				
				// Update the client text and client shadow
				clientShadow = serverUpdates[0];
				textString = dmp.patch_apply(list_of_patches_server, clientText);
				clientText = (String) textString[0];
				
				System.out.println("The updated client text is: ");
				System.out.println(clientText);

			}
		} catch (IOException ioe) {
			System.out.println("ioe in Client run: " + ioe.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println("class not found in Client run: " + e.getMessage());
		}
	}
}
