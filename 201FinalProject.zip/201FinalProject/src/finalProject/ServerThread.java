package finalProject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Time;
import java.util.LinkedList;



public class ServerThread extends Thread {
	private Server server;
	private Socket socket;
	private ObjectOutputStream oos;
    private ObjectInputStream ois;
    
    private String serverText = "";
	private transient LinkedList<diff_match_patch.Patch> list_of_patches_client;
	private String serverShadow = "";
	private static diff_match_patch dmp;
	
	public String docID; 
	
	public int id; 
	
	

	public ServerThread(Socket s, Server server, int id) {
		
		this.id = id; 
		
		dmp = new diff_match_patch();
		this.server = server;
		this.socket = s;
		try {
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());

		
			docID = (String) ois.readObject(); //blocking

			server.addDocument(docID);
			
			serverText = server.readDocument(docID); 
			serverShadow = serverText; 
			oos.writeObject(serverText);
//			System.out.println("ServerThread sent doc info");
			
		} catch (IOException e) {
			System.out.println("ioe in ServerThread: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		this.start();
		
	}

	public void run() {

		Object[] textString;

		// Continuouly wait for updates from the client and properly patch the server and other client texts
		while(true) {
			try {
				
				// Get the client shadow and new client text
				System.out.println("Hello from before blocking stuff in st " + id);
				String[] clientUpdates = (String[])ois.readObject();  // blocking
				System.out.println("hello from after blocking line in st " + id);

				// Calculate the patches on the client side
				list_of_patches_client = dmp.patch_make(clientUpdates[0], clientUpdates[1]);
				
				serverShadow = clientUpdates[1];

				// Update the server text
				synchronized (Server.class) {
					textString = dmp.patch_apply(list_of_patches_client, serverText);
					serverText = (String) textString[0];
					
					server.updateDocument(docID, serverText);
				}
				serverShadow = serverText;
				
				System.out.println("The updated server text for " + id + " is: ");
				System.out.println(serverText);

				// Broadcast to all other clients about the updated server text
				System.out.println("calling broadcast " + id);
				server.broadcast(this);

			} catch (ClassNotFoundException e) {
				System.out.println("class not found in ServerThread: " + e.getMessage());
			} catch (IOException e) {
				System.out.println("ioe in ServerThread: " + e.getMessage());
				System.exit(1);
			}
		}
	}

	public void updateClientText() {
		try {
			
			System.out.println("trying to send info to client matched to st " + id);
			
			serverText = server.readDocument(docID); 
			String[] serverUpdates = {serverText, serverShadow};
			
			System.out.println("Planning to send to " + id+ " : " + serverUpdates[0] + ", " + serverUpdates[1]);
			
			oos.writeObject(serverUpdates);
			serverShadow = serverText;
			
			System.out.println("The server thread " + id + " sent " + serverText);
			
		} catch (IOException e) {
			System.out.println("ioe in ServerThread updateClientText: " + e.getMessage());
		}
	}
}
