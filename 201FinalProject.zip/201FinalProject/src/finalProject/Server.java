package finalProject;

import java.io.IOException;

import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.Vector;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Server {
	private Vector<ServerThread> serverThreads;
	
	private Connection conn;
	private Statement st;
	private PreparedStatement ps;
	private ResultSet rs;
	private Map<String, String> idMap = Collections.synchronizedMap(new HashMap<>());
	private Login authenticator; 
	
	public Server() {

		int port = 6789;

		// Connect to the port
		try {
			
			//update this statement to work with your mysql database
			conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproj?user=root&password=MAkdessi22&serverTimezone=UTC");
			st = conn.createStatement();
			
			authenticator = new Login();
			
			ServerSocket ss = new ServerSocket(port);
			System.out.println("Listening on port " + port + ".");
			serverThreads = new Vector<ServerThread>();
			
			Updater thing = new Updater(); 
			thing.start();
			int count = 0; 
			// Add every client to a new server thread
			while(true) {
				Socket s = ss.accept(); //blocking waiting for clients
				System.out.println("Connection from " + s.getInetAddress());
				ServerThread st = new ServerThread(s, this, count);
				serverThreads.add(st);
				count++; 
			}
			
		} catch (IOException ioe) {
			System.out.println("ioe in bindToPort: " + ioe.getMessage());
		}
//		catch(SQLException sqle){
//			System.out.println ("SQLException: " + sqle.getMessage());
//		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("SQL error: ");
			e.printStackTrace();
			
		}
	}

	public static void main(String args[]) {
		Server server = new Server();
	}
	
	
	public synchronized void updateDocument(String id, String content) {
		idMap.put(id, content); 
	}
	
	public void addDocument(String id) {
		try {
			if (idMap.containsKey(id) == false) {
				
				ps = conn.prepareStatement("SELECT * FROM Documents WHERE(documentID = '" + id +"')");		
				rs = ps.executeQuery();
				rs.next(); 
				
				String content = rs.getString("DocumentContent"); 
				
				if (content == null) {
					content = ""; 
				}
				
				String fixedContent = new String(); 
				for(Character ch : content.toCharArray()) {
					if (ch == ';') {
						fixedContent += (char) 39;
					}
//					else if (ch == '$') { // new line 
//						fixedContent += (char) 10;
//					}
//					else if (ch == '@') { // tab
//						fixedContent += (char) 9;
//					} 
					else {
						fixedContent += ch; 
					}
				}
				
				idMap.put(id, fixedContent); 
			}
			
		} catch(SQLException sqle) {
			System.out.println("SQLException in fetching document: " + sqle.getMessage());
		}
	}
	
	public String readDocument(String id) {
		return idMap.get(id); 
	}
	
	public synchronized void broadcast(ServerThread serverThreadOrigin) {
		
		System.out.println("hello from broadcast");
		
		for (ServerThread st : serverThreads) {
			if (st != serverThreadOrigin && st.docID.equals(serverThreadOrigin.docID)) {
				st.updateClientText();
				System.out.println("broadcasting to " + st.id);
			}
			else {
				System.out.println("not broadcasting to " + st.id);
			}
		}
	}
	
	class Updater extends Thread{
		
		public Updater(){
			this.setPriority(MIN_PRIORITY);
		}
		
		public void run() {
			
			try {
				while (true) {
					Thread.sleep(5000);
					
					for(String docID: idMap.keySet()) {
						
						String fixedContent = new String(); 
						for(Character ch : idMap.get(docID).toCharArray()) {
							if (ch == (char) 39) {
								fixedContent += ';';
							}
//							else if (ch == (char) 10) { // new line
//								fixedContent += '$';
//							}
//							else if (ch == (char) 9) { // tab
//								fixedContent += '@';
//							}
							else {
								
								fixedContent += ch; 
							}
						}
						
						
						st.executeUpdate("UPDATE Documents SET DocumentContent='" + fixedContent + "' "
								+ "WHERE documentID='" + docID + "' "); 						
					}
				}		
					
			} catch (InterruptedException e) {
				// no interrupts dw
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			}
		}
	}
}




