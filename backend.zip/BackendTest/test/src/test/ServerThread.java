package test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.sql.Time;
import java.util.LinkedList;



public class ServerThread extends Thread {
	private Server server;
	private Socket socket;
	private ObjectOutputStream oos;
    private ObjectInputStream ois;
    
    private String serverText = "";
	private transient LinkedList<test.diff_match_patch.Patch> list_of_patches_client;
	private String serverShadow = "";
	private static diff_match_patch dmp;
	
	public String docID; 
	
	

	public ServerThread(Socket s, Server server) {
		
		dmp = new diff_match_patch();
		this.server = server;
		this.socket = s;
		try {
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());

			boolean failed = true; 
			
			while (failed) {
				String username = (String) ois.readObject();
				String password = (String) ois.readObject();
				String passed = server.checkAccount(username, password);
				if (passed.equals("y")) {
					failed = false; 
				}
				else {
					System.out.println(passed);
					// sending error message to client
					oos.writeObject(passed);
				}
			}
			
			// letting client know they are logged in 
			oos.writeObject("y");
			
		
			docID = (String) ois.readObject(); //blocking

			server.addDocument(docID);
			
			serverText = server.readDocument(docID); 
			oos.writeObject(serverText);
//			System.out.println("ServerThread sent doc info");
			
		} catch (IOException e) {
			System.out.println("ioe in ServerThread: " + e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		this.start();
		
	}

	public void run() {

		Object[] textString;

		// Continuouly wait for updates from the client and properly patch the server and other client texts
		while(true) {
			try {
				
				// Get the client shadow and new client text
				String[] clientUpdates = (String[])ois.readObject(); 

				// Calculate the patches on the client side
				list_of_patches_client = dmp.patch_make(clientUpdates[0], clientUpdates[1]);			
				serverShadow = clientUpdates[1];

				// Update the server text
				synchronized (Server.class) {
					textString = dmp.patch_apply(list_of_patches_client, serverText);
					serverText = (String) textString[0];
					
					server.updateDocument(docID, serverText);
				}
				serverShadow = serverText;
				
				System.out.println("The updated server text is: ");
				System.out.println(serverText);

				// Broadcast to all other clients about the updated server text
				server.broadcast(this);

			} catch (ClassNotFoundException e) {
				System.out.println("class not found in ServerThread: " + e.getMessage());
			} catch (IOException e) {
				System.out.println("ioe in ServerThread: " + e.getMessage());
				System.exit(1);
			}
		}
	}

	public void updateClientText() {
		try {
			serverText = server.readDocument(docID); 
			String[] serverUpdates = {serverText, serverShadow};
			oos.writeObject(serverUpdates);
			serverShadow = serverText;
		} catch (IOException e) {
			System.out.println("ioe in ServerThread updateClientText: " + e.getMessage());
		}
	}
}
