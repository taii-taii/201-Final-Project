package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Login {
	Connection conn;
	Statement st;
	PreparedStatement ps;
	ResultSet rs;
	
	public Login(Connection conn, Statement st){
		this.conn = conn; 
		this.st = st;			
	}
	
	public void ResetPassword(String email, String newPassword) throws SQLException{
		if(!VerifyUser(email)){
			System.out.println("User doesn't exist.");
			return;
		} else {
			st.executeUpdate("UPDATE Users SET password='" + newPassword + "' WHERE email='" + email + "'");
		}
	}
	
	public void CreateUser(String email, String password) throws SQLException{
		if(VerifyUser(email)){
			System.out.println("User already exists.");
			return;
		}
		st.executeUpdate("INSERT INTO Users VALUES ('" + email + "','" + password + "')");
	}
	
	public boolean CheckPassword(String email, String password) throws SQLException{
		if(VerifyUser(email)){
			ps = conn.prepareStatement("SELECT * FROM Users WHERE email='" + email + "'");
			rs = ps.executeQuery();
			rs.next();
			if(rs.getString("password").equals(password)){
				return true;
			}
		}
		return false;
	}
	
	public boolean VerifyUser(String email) throws SQLException{				
		ps = conn.prepareStatement("SELECT EXISTS(SELECT * FROM Users WHERE email='" + email +"')");
		rs = ps.executeQuery();

		rs.next();
		if(rs.getBoolean(1)){
			return true;
		}
		return false;
	}
	
}

